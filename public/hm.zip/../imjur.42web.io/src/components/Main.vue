<template>
  <div class="main" ref="main" tabindex="0">
    <div v-if="showUploadProgress" class="uploadProgressContainer">
      <br>uploading {{filesUploading.length}} file{{filesUploading.length > 1 ? 's':''}}...
      <div class="progressBar" v-for="file in filesUploading">
        <div class="progressBarInnerOutline">
          <div class="progressBarInner" :style="'width:calc(' + (file.perc) + '%)'"></div>
        </div>
        <span class="progressText" v-html="(Math.round(file.perc*100)/100) + '%' + ' - ' + shortUploadName(file.uploadName)"></span>
      </div>
    </div>
    <div
      v-if="state.showUploadModal"
      class="uploadModal"
      :class="{'dragover': dragover}"
      @drop.prevent="processDrop"
      @dragover.prevent="dragOverHandler"
      @dragleave.prevent="dragLeaveHandler"
    >
      <div class="uploadModalInner">
        <span style="font-size: 2em;color: #888">upload tracks</span><br><br>
        <br>valid formats<br><br>
        MP3, OGG, WAV<br><br><br>
        <span style="font-size: 1.4em;color: #ff0">drop file(s) here...</span><br>
        <br>or<br><br>
        <button @click="uploadManual()" style="background: #0f0;max-width: 400px;">manually select one from your device</button><br><br>
        <button @click="state.showUploadModal = false" style="background: #400;color: #fee;font-weight: 400;">cancel</button>
      </div>
    </div>
    <div
      id="dropTarget"
      class="dropTarget"
      @dragover.prevent
      @drop.prevent="dropFiles($event)"
      @click=""
      ref="dropTarget"
    >
      <div
        ref="dropTargetCaption"
        id="dropTargetCaption"
        v-if="!(state.userLinks.length || state.links.length || state.loadingAssets)"
        style="cursor: pointer;"
        @click="this.loadFiles()"
      >
        throw sum filez [click/drop]<br><br>
        accepted : gif<br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;web[p/m]<br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;png<br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;jp[e]g<br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;mp4<br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;mp3<br><br>
        max size : 25MB<br>
        <span style="font-size: .7em;">(per file)</span><br><br>
        max files: 15<br>
        <span style="font-size: .7em;">(at a time)</span><br><br><br>
        <div style="font-size: .6em;">
        WARRANTY: none<br><br>
        this website is a work-in-progress.<br>
        your files will likely be deleted</div>
      </div>
      <div v-if="state.links.length || state.userLinks.length" class="links">
        <Link
          :state="state"
          v-for="link in state.links"
          :link="link"
          :linkMode="'link'"
          :key="link.id"
          v-if="state.links.length"
        />
        <Link
          :state="state"
          v-for="link in state.userLinks"
          :link="link"
          :linkMode="'userLink'"
          :key="link.id"
          v-if="state.userLinks.length"
        />
      </div>
    </div>
  </div>
</template>

<script>
import Link from './Link'

export default {
  name: 'Main',
  props: [ 'state' ],
  components: {
    Link
  },
  data(){
    return {
      preload: [],
      rejects: [],
      dragover: false,
      showUploadProgress: false,
      filesUploading: []
    }
  },
  methods: {
    shortUploadName(str){
      let ret = str
      if(ret.length > 43) ret = ret.substring(0, 30) + '...' + ret.substring(ret.length-10)
      return ret
    },
    dragLeaveHandler(){
      this.dragover = false
    },
    dragOverHandler(){
      this.dragover = true
    },
    processUpload(files){
    
      if(!files.length) return
      this.showUploadProgress = true
      this.$refs.main.style.zIndex = 100000
      this.filesUploading = Array(files.length).fill().map(v=>{return {}})
      console.log(files)
      Array.from(files).forEach((v, i)=>{
        v.completed = false
        this.filesUploading[i].perc = 0
        this.filesUploading[i].uploadName = v.name
      })
        
      let ct = 0
      files.map((file, i) => {
        console.log(`file ${i}: `, file)
        if((
          file.type == 'image/gif' ||
          file.type == 'image/jiff' ||
          file.type == 'image/jpeg' ||
          file.type == 'image/jpg' ||
          file.type == 'image/png' ||
          file.type == 'image/webp' ||
          file.type == 'video/mp4' ||
          file.type == 'video/webm' ||
          file.type == 'video/mkv' ||
          file.type == 'audio/mp3' ||
          file.type == 'audio/wav' ||
          file.type == 'audio/mpeg') &&
          file.size < 25000000){
          ct++
        } else {
          this.rejects = [...this.rejects, file]
        }
      })
      
      let rej = '<div style="min-width:90vw; min-height: 50vh; position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%);background: #4008; color: #f88; padding-top: 100px;">'
      this.rejects.map(reject=>{
        let sz = (reject.size/(1024**2)|0).toLocaleString('en-us') + ' MB<br>'
        rej += `oversized/rejected: size: ${sz} "${reject.name}" <br><br>`
      })
      if(this.rejects.length) {
        this.state.modalQueue = [...this.state.modalQueue, rej + '</div>']
        this.state.closeModal()
      } else if(ct) {
        Array.from(files).forEach((v, i) => {
          let batchMetaData = {
            loggedIn: this.state.loggedIn,
            userID: this.state.loggedinUserID,
            passhash: this.state.passhash,
            description: '',
          }
          console.log('batchMetaData', batchMetaData)
          let data = new FormData()
          data.append(`uploads_${0}`, v)
          //data.append('file', v)
          data.append('batchMetaData', JSON.stringify(batchMetaData))
          let request = new XMLHttpRequest()
          request.open('POST', 'upload.php')
          request.upload.addEventListener('progress', e => {
            let perc = (e.loaded / e.total)*100
            this.filesUploading[i].uploadName = v.name
            this.filesUploading[i].perc = perc
          })
          request.addEventListener('load', e=> {
            v.completed = true
            let finished = true
            Array.from(files).forEach(q=>{
              if(!q.completed) finished = false
            })
            if(finished) {
              this.showUploadProgress = false
              this.$refs.main.style.zIndex = 0
              this.state.modalContent = ''
              this.state.closeModal()
              if(this.state.loggedIn){
                console.log('logged in tho?')
                this.state.links = []
                this.state.fetchUserLinks(this.state.loggedinUserID)
                this.state.jumpToPage(0)
              }else{
                this.state.modalContent = '<div style="box-sizing: border-box;min-width:90vw; min-height: 50vh; position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%);background: #0846; color: #8f8; padding: 100px; text-align: left;">' + `excellent choice, uploading here...<br><br>you have not logged in though, which means your links will be lost soon.<br><br>If you register, nothing is needed except a name of your choosing and a password you will remember, then these uploads will be auto-saved to your new profile...<br><br>just don't close the page or refresh before you login or register!<br><br><br>thanks for using imjur!` + '</div>'
                this.state.showModal = true
                this.state.showRegister = true
                this.state.showLoginPrompt = true
              }
            }
            if(e.currentTarget.responseText[0] != '<'){
              let data = JSON.parse(e.currentTarget.responseText)
              if(data[0]){
                data[1].map((v, j)=>{
                  //addLink(size, type, ct, href, selected, userID, slug, originalSlug, origin, serverTZO, views, ids){
                  this.addLink(data[2][j], data[3][j], i, v, false, this.state.loggedinUserID, data[6][j], data[7][j], data[8][j], data[9], data[10][j], data[11][j], data[12][j],data[13][j])
                })
              }else{
                this.state.modalContent = '<div style="min-width:90vw; min-height: 50vh; position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%);background: #8002; color: #f88; padding-top: 100px;">' + data[5] + '</div>'
              }
            }
          })
          request.send(data)
        })
      }else{
        this.$refs.main.style.zIndex = 0
        alert('no files were uploaded. hmmmm. mebbe too big tho')
        this.state.closeModal()
        this.showUploadProgress = false
      }
    },
    dropFiles(e){

      /*let files = document.createElement('input')
      files.type = 'file'
      files.name = 'uploads[]'
      files.multiple = true
      files.accept = 'image/gif, image/jiff, image/jpeg, image/jpg, image/png, image/webp, video/mp4, video/webm, video/mkv, audio/mp3, audio/wav, audio/mpeg'
      files.files = []*/
      
      let files = []
      if(e.dataTransfer.items){
        [...e.dataTransfer.items].forEach((item, i) => {
          if (item.kind === "file") {
            const file = item.getAsFile()
            files = [...files, file]
          }
        })
      }else{
        files = Array.from(e.dataTransfer.files)
      }
      if(files.length) this.processUpload(files)
    },
    addLink(size, type, ct, href, selected, userID, slug, originalSlug, origin, serverTZO, views, id, date, originalDate){
    
      let obj = {
        size,
        type,
        ct,
        href,
        slug,
        origin,
        selected,
        userID,
        id,
        originalSlug,
        linkType: 'link',
        serverTZO,
        views,
        date,
        originalDate
      }
      this.state.links.push(obj)
    },
    loadFiles(){
      //if(this.state.links.length) return
      // uncomment above to disable subsequent
      // click->open-file-dialog, after 1 successful upload
      
      let files = document.createElement('input')
      files.type = 'file'
      files.multiple = true
      files.accept = 'image/gif, image/jiff, image/jpeg, image/jpg, image/png, image/webp, video/mp4, video/webm, video/mkv, audio/mp3, audio/wav, audio/mpeg'
      files.onchange = () => this.processUpload(Array.from(files.files))
      files.click()
    }
  },
  mounted(){
    this.$refs.main.focus()
    this.state.loadFiles = this.loadFiles
    this.preload = [ ...this.preload,
      [document.createElement('video'), 'loading.mp4'],
    ]
    this.preload.map(v => {
      v[0].src = this.state.URLbase + '/' + v[1]
    })
  }
}
</script>

<style scoped>
  .main{
    background-color: #000011ee;
    font-size: 20px;
    overflow-y: scroll;
    overflow-x: hidden;
    height: 100%;
    padding: 0px;
    box-sizing: border-box;
    text-align: center;
    position: absolute;
    padding-top: 100px;
    z-index: 0;
    padding-bottom: 200px;
    width: 100vw;
  }
  /*.dropTarget:hover{
    background-color: #0648;
    cursor: pointer;
  }*/
  .dropTarget{
    color: #0f8;
    display: inline-block;
    text-align: left;
    background-repeat: no-repeat;
    background-position: center center;
    background-size: 100% 100%;
    border-radius: 10px;
    /*background-image: url(../assets/loading.gif);*/
    /*border: 1px solid #4088;*/
    /*background-color: #0468;*/
    width: 100%;
    min-height: calc(100% - 10px);
    box-sizing: border-box;
  }
  .links{
    margin: 0;
    box-sizing: border-box;
    text-align: center;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-evenly;
  }
  @keyframes colorCycle{
    0% {
      background-color:  #ff000022;
      box-shadow: 0 0 150px 150px #ff000022;
    }
    5% {
      background-color: #ff4c0022;
      box-shadow: 0 0 150px 150px #ff4c0022;
    }
    10% {
      background-color: #ff990022;
      box-shadow: 0 0 150px 150px #ff990022;
    }
    15% {
      background-color: #ffe50022;
      box-shadow: 0 0 150px 150px #ffe50022;
    }
    20% {
      background-color: #ccff0022;
      box-shadow: 0 0 150px 150px #ccff0022;
    }
    25% {
      background-color: #7fff0022;
      box-shadow: 0 0 150px 150px #7fff0022;
    }
    30% {
      background-color: #32ff0022;
      box-shadow: 0 0 150px 150px #32ff0022;
    }
    35% {
      background-color: #00ff1922;
      box-shadow: 0 0 150px 150px #00ff1922;
    }
    40% {
      background-color: #00ff6522;
      box-shadow: 0 0 150px 150px #00ff6522;
    }
    45% {
      background-color: #00ffb222;
      box-shadow: 0 0 150px 150px #00ffb222;
    }
    50% {
      background-color: #00ffff22;
      box-shadow: 0 0 150px 150px #00ffff22;
    }
    55% {
      background-color: #00b2ff22;
      box-shadow: 0 0 150px 150px #00b2ff22;
    }
    60% {
      background-color: #0065ff22;
      box-shadow: 0 0 150px 150px #0065ff22;
    }
    65% {
      background-color: #0019ff22;
      box-shadow: 0 0 150px 150px #0019ff22;
    }
    70% {
      background-color: #3300ff22;
      box-shadow: 0 0 150px 150px #3300ff22;
    }
    75% {
      background-color: #7f00ff22;
      box-shadow: 0 0 150px 150px #7f00ff22;
    }
    80% {
      background-color: #cb00ff22;
      box-shadow: 0 0 150px 150px #cb00ff22;
    }
    85% {
      background-color: #ff00e522;
      box-shadow: 0 0 150px 150px #ff00e522;
    }
    90% {
      background-color: #ff009822;
      box-shadow: 0 0 150px 150px #ff009822;
    }
    95% {
      background-color: #ff004c22;
      box-shadow: 0 0 150px 150px #ff004c22;
    }
    100% {
      background-color: #ff000022;
      box-shadow: 0 0 150px 150px #ff000022;
    }
  }
  #dropTargetCaption{
    display: inline-block;
    width: 340px;
    position: fixed;
    left: 50%;
    top: calc(50% - 24px);
    transform: translate(-50%, -50%);
    padding: 38px;
    border-radius: 32%;
    height: 320px;
    padding-top: 0;
    padding-right: 28px;
    background-color: #103c;
    box-shadow: 0 0 150px 150px #103c;
    /*animation: colorCycle 5s infinite linear;*/
  }
  .uploadModal{
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: #001d;
    z-index: 100000;
    line-height: 1.05em;
  }
  .uploadProgressContainer{
    position: fixed;
    top: 0;
    left: 0;
    overflow: auto;
    width: 100vw;
    height: 100vh;
    background: #102d;
    z-index: 100000;
    line-height: 1.05em;
    color: #f00;
    font-size: 24px;
  }
  .uploadModalInner{
    position: absolute;
    top: calc(50% - 60px);
    left: 50%;
    width: 400px;
    height: 280px;
    background: #103b;
    z-index: 100000;
    box-shadow: 0px 0px 100px 100px #103b;
    transform: translate(-50%, -50%);
    border-radius: 10px;
  }
  .dragover{
    background: #0246;
  }
  .progressBar{
    width: 80%;
    height: 16px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 10px;
  }
  .progressBarInner{
    background: #40f8;
    height: 100%;
  }
  .progressBarInnerOutline{
    border: 1px solid #84f3;
    height: 100%;
  }
  .progressText{
    position: relative;
    font-size: 17px;
    color: #dbf;
    right: 50%;
    transform: translate(50%, -85%);
    text-shadow: 1px 1px 2px #000;
    display: inline-block;
  }
</style>

